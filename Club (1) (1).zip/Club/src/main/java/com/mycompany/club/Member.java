/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.club;

import java.util.ArrayList;

/**
 *
 * @author HP 15S-EQ2019NS
 */
public class Member {//preguntar atributo publico para no utilizar get y set
    public int id;
    public String name;
    public double availableFunds;
    public String subscriptionType;
    ArrayList<Invoice> unpaidInvoices;//facturas sin pagar
    ArrayList<Person> authorizedPersons;
    
    //constructor para tomar datos
    public Member(int id, String name, String subscriptionType) {
        this.id=id;
        this.name=name;
        this.subscriptionType=subscriptionType;
        //monto fondo inicial: 100 mil si es VIP o 50 mil si es regular.
        if (subscriptionType=="VIP") {
            this.availableFunds=100000;
        } else {
            this.availableFunds=50000;
        }        
        this.unpaidInvoices=new ArrayList<>();
        this.authorizedPersons=new ArrayList<>();
}
    public void addAuthorizedPerson(Person person) {
    if (authorizedPersons.size()<10){
        authorizedPersons.add(person);
    } else {
        System.out.println("Máximo de personas a asociar: 10.");
    }
}
    

}
