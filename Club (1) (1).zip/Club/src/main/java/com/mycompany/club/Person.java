/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.club;

/**
 *
 * @author HP 15S-EQ2019NS
 */
public class Person{
    public int personId;
    public String personName;

    public Person(int personId,String personName){
        this.personId=personId;
        this.personName=personName;
    }
}
